<a name="1.0.4"></a>
## [1.0.4](https://github.com/dreambo8563/vue-particle-effect-buttons/compare/v1.0.3...v1.0.4) (2019-08-22)


### Bug Fixes

* **base.css:** fixd page too wide on windows ([b37bee5](https://github.com/dreambo8563/vue-particle-effect-buttons/commit/b37bee5))



<a name="1.0.3"></a>
## [1.0.3](https://github.com/dreambo8563/vue-particle-effect-buttons/compare/v1.0.2-beta.0...v1.0.3) (2019-04-28)


### Bug Fixes

* **log:** rm log ([f93f050](https://github.com/dreambo8563/vue-particle-effect-buttons/commit/f93f050))



<a name="1.0.2-beta.0"></a>
## [1.0.2-beta.0](https://github.com/dreambo8563/vue-particle-effect-buttons/compare/v1.0.1...v1.0.2-beta.0) (2019-04-28)



<a name="1.0.1"></a>
## [1.0.1](https://github.com/dreambo8563/vue-particle-effect-buttons/compare/v1.0.0...v1.0.1) (2019-04-26)



<a name="1.0.0"></a>
# [1.0.0](https://github.com/dreambo8563/vue-particle-effect-buttons/compare/v0.1.3...v1.0.0) (2019-04-25)


### Features

* **implement:** almost done ([cd505a4](https://github.com/dreambo8563/vue-particle-effect-buttons/commit/cd505a4))



<a name="0.1.3"></a>
## [0.1.3](https://github.com/dreambo8563/vue-particle-effect-buttons/compare/v0.1.2...v0.1.3) (2019-04-25)


### Bug Fixes

* **dup complete event:** buttonVisible ([6ef89f3](https://github.com/dreambo8563/vue-particle-effect-buttons/commit/6ef89f3))



<a name="0.1.2"></a>
## [0.1.2](https://github.com/dreambo8563/vue-particle-effect-buttons/compare/v0.1.1...v0.1.2) (2019-04-24)


### Bug Fixes

* **rename:** to vue-particle-effect-buttons to resolve conflict ([926e056](https://github.com/dreambo8563/vue-particle-effect-buttons/commit/926e056))



<a name="0.1.1"></a>
## [0.1.1](https://github.com/dreambo8563/vue-particle-effect-buttons/compare/b3f6a61...v0.1.1) (2019-04-24)


### Features

* **implement:** basic implement and ci ([b3f6a61](https://github.com/dreambo8563/vue-particle-effect-buttons/commit/b3f6a61))



